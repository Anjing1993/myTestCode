import { ComponentClass } from 'react'


export {
  RadioProps as OsRadioProps,
  Radio as OsRadio,
  RadioOptionProps as OsRadioOptionProps,
  RadioOption as OsRadioOption
} from './radio'
export {
  CheckboxProps as OsCheckboxProps,
  Checkbox as OsCheckbox,
  CheckboxOptionProps as OsCheckboxOptionProps,
  CheckboxOption as OsCheckboxOption
} from './checkbox'