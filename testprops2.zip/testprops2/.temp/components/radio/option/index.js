import Taro from "@tarojs/taro-h5";
import Nerv from "nervjs";
import { View } from '@tarojs/components';
import classNames from 'classnames';
// import styles from './index.module.scss'
var styles = require('./index.module.scss');
// function getStyleObj(props: Props) {
//   let _styleObj = {}
//   return _styleObj;
// }
function getClassObject(props) {
  const classObject = {
    [styles['radio__option--disabled']]: props.isDisabled,
    [styles['radio__option--unexec']]: props.isReadonly,
    [styles['radio__option--custom-label']]: props.isCustom,
    [styles[`radio__option--dir-${props.type}`]]: true
  };
  return classObject;
}
export default class RadioOption extends Taro.Component {
  render() {
    const props = this.props;

    const rootClassName = styles['radio__option']; //组件
    const classObject = getClassObject(props); //组件修饰
    //const styleObject = getStyleObj(props);
    const onClickOption = props => {
      if (props.isDisabled || props.isReadonly) return;
      props.onClick(props.optionValue);
    };
    let iconType = 'check';
    if (props.value === props.optionValue) {
      if (props.isReadonly) {
        iconType = 'check-irrevocable';
      } else if (props.value === props.optionValue) {
        iconType = 'check-selected';
      }
    }
    return <View className={classNames([rootClassName, styles['radio-option-root-class'], classObject, props.className])} onClick={() => onClickOption(props)}>
      
      <View className={styles['radio__option-label']}>{props.children}</View>
    </View>;
  }

}
RadioOption.defaultProps = {
  type: 'column'
};
RadioOption.options = {
  addGlobalClass: true
};