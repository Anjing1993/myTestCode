import Taro from "@tarojs/taro-h5";
import Nerv from "nervjs";
import { View } from '@tarojs/components';
import classNames from 'classnames';
// import styles from './index.module.scss'
var styles = require('./index.module.scss');
function getStyleObj(props) {
  let _styleObj = {};
  return _styleObj;
}
function getClassObject(props) {
  const classObject = {
    [`radio--dir-${props.type}`]: true
  };
  return classObject;
}
export default class Index extends Taro.Component {
  render() {
    const props = this.props;

    const rootClassName = styles['radio']; //组件
    const classObject = getClassObject(props); //组件修饰
    const styleObject = getStyleObj(props);
    return <View className={classNames(rootClassName, styles['radio-root-class'], classObject, props.className)} style={styleObject}>
      
       {props.children}
    </View>;
  }

}
Index.defaultProps = {
  type: 'column'
};
// Index.options = {
//   addGlobalClass: true
// }