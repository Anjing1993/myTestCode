/* eslint-disable */
// @ts-nocheck
/*
 * ------------------------------------------
 * 配合严选APP的jsbridge
 * @version  1.0
 * @author   wj(hzwangjing1@corp.netease.com)
 *
 * ------------------------------------------
 * demo
 * var jsbridge = require('extend/jsbridge');
 *
 * jsbridge.ready(function() {
 *   imagePick(options, callback)
 * })
 */
/* eslint-disable */
function listenOnce(eventName, callback) {
  window[eventName] = function (result, type) {
    // eslint-disable-line no-undef
    window[eventName] = null; // eslint-disable-line no-undef
    callback(result, type); // eslint-disable-line no-undef
  };
}

function invoke(methodName, params) {
  NEJsbridge.call(methodName, JSON.stringify(params)); // eslint-disable-line no-undef
}
var jsbridge = {
  ready: function (init) {
    function handler() {
      //防止安卓多次响应
      document.removeEventListener('NEJsbridgeReady', handler);
      init();
    }

    if (window.NEJsbridge) {
      // eslint-disable-line no-undef
      init();
    } else {
      document.addEventListener('NEJsbridgeReady', handler);
    }
  },
  //上传图片
  imagePick: function (options, callback) {
    invoke('imagePick', options);
    listenOnce('onImagePickResult', function (res) {
      if (res.imageData && res.imageData.length) {
        res.imageData = res.imageData.map(function (str) {
          return str;
        });
      }
      callback && callback(res);
    });
  }
};

export default jsbridge;