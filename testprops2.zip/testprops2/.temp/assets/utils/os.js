/* eslint-disable */
/*
 * ------------------------------------------
 * 判断 手机设备 仅在 navigator.userAgent 存在时有效
 * @version  1.0
 * @author   wj(hzwangjing1@corp.netease.com)
 *
 */
import Taro from "@tarojs/taro-h5";
let ua = '';
let touchRegExp = '';
let isYanxuan = '';
let isAndroid = false;
let isIos = false;
let isTouch = false;
let yanxuanAppVer = '';
if (Taro.getEnv() !== Taro.ENV_TYPE.WEAPP && Taro.getEnv() !== Taro.ENV_TYPE.ALIPAY && Taro.getEnv() !== Taro.ENV_TYPE.SWAN && Taro.getEnv() !== Taro.ENV_TYPE.RN && Taro.getEnv() !== Taro.ENV_TYPE.TT) {
  ua = navigator.userAgent;
  touchRegExp = new RegExp('(MIDP)|(WAP)|(UP.Browser)|(Smartphone)|(Obigo)|(Mobile)|(AU.Browser)|(wxd.Mms)|(WxdB.Browser)|(CLDC)|(UP.Link)|(KM.Browser)|(UCWEB)|(SEMC-Browser)|(Mini)|(Symbian)|(Palm)|(Nokia)|(Panasonic)|(MOT-)|(SonyEricsson)|(NEC-)|(Alcatel)|(Ericsson)|(BENQ)|(BenQ)|(Amoisonic)|(Amoi-)|(Capitel)|(PHILIPS)|(SAMSUNG)|(Lenovo)|(Mitsu)|(Motorola)|(SHARP)|(WAPPER)|(LG-)|(LG/)|(EG900)|(CECT)|(Compal)|(kejian)|(Bird)|(BIRD)|(G900/V1.0)|(Arima)|(CTL)|(TDG)|(Daxian)|(DAXIAN)|(DBTEL)|(Eastcom)|(EASTCOM)|(PANTECH)|(Dopod)|(Haier)|(HAIER)|(KONKA)|(KEJIAN)|(LENOVO)|(Soutec)|(SOUTEC)|(SAGEM)|(SEC-)|(SED-)|(EMOL-)|(INNO55)|(ZTE)|(iPhone)|(Android)|(Windows CE)', 'i');
  isYanxuan = /yanxuan/i.test(ua);
  isAndroid = /android/i.test(ua);
  isIos = !isAndroid;
  isTouch = touchRegExp.test(ua);
  yanxuanAppVer = function () {
    let version = navigator.userAgent.toLowerCase().match(/yanxuan\/(\d+\.\d+\.\d+)/);
    if (version) {
      return version[version.length - 1];
    }
    return '0.0.0';
  }();
}
export default {
  isYanxuan,
  isAndroid,
  isIos,
  isTouch,
  yanxuanAppVer
};