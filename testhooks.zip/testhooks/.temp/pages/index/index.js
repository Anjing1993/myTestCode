import Nerv from "nervjs";
import Taro, { setNavigationBarTitle as _setNavigationBarTitle } from "@tarojs/taro-h5";
import { View } from '@tarojs/components';
import classNames from 'classnames';
import Select from "../../components/checkbox/index";
export default class Index extends Taro.Component {
  render() {
    const classObject = 'test'; //组件修饰
    const [v1, setV1] = Taro.useState([0]);
    Taro.useEffect(() => {
      _setNavigationBarTitle({
        title: 'Checkbox 复选框'
      });
    }, []);
    function onClick(value) {
      debugger;
      setV1(value);
    }
    return <View className={classNames(classObject)}>
     <Select className="test1" optionValue={0} value={v1} onClick={value => onClick(value)}></Select>
     <Select className="test1" optionValue={1} value={v1} onClick={value => onClick(value)}></Select>
    </View>;
  }

  componentDidMount() {
    super.componentDidMount && super.componentDidMount();
  }

  componentDidShow() {
    super.componentDidShow && super.componentDidShow();
  }

  componentDidHide() {
    super.componentDidHide && super.componentDidHide();
  }

}