import Nerv from "nervjs";
import Taro, { setNavigationBarTitle as _setNavigationBarTitle } from "@tarojs/taro-h5";
import { View, Swiper, SwiperItem, Image } from '@tarojs/components';
import classNames from 'classnames';
// import Select from '../../components/checkbox'
// import OsRadio from '../../components/radio'
// import OsRadioOption from '../../components/radio/option/index'
import './index.scss';
export default class Index extends Taro.Component {
  render() {
    const classObject = 'test'; //组件修饰
    const [v1, setV1] = Taro.useState([0]);
    const [v2, setV2] = Taro.useState(0);
    let [count, setCount] = Taro.useState(1);
    const initImg1 = [{
      imgSrc: 'https://yanxuan.nosdn.127.net/fe726ef94ce6a26a666e84361dbd6f4d.jpg?imageView&quality=75&thumbnail=670x371'
    }, {
      imgSrc: 'http://yanxuan.nosdn.127.net/07760022c7752f9d5ac51e8564fc8fd7.jpg?imageView&quality=75&thumbnail=670x371'
    }, {
      imgSrc: 'https://yanxuan.nosdn.127.net/27394a4590fb4af710655a15bc617895.jpg?imageView&quality=75&thumbnail=670x371'
    }];
    Taro.useEffect(() => {
      _setNavigationBarTitle({
        title: '测试 props.children'
      });
    }, []);
    function onClick(value) {
      setV1(value);
    }
    return <View className={classNames(classObject)}>
    
    
    
    

    

    
    <Swiper autoplay style={{ width: Taro.pxTransform(670), height: Taro.pxTransform(440) }} interval={1000} circular vertical>
    
    {initImg1.map((item, index) => <SwiperItem>
        <View onClick={() => {
            setCount(index + 1);
          }}>
        <View style={'font-size:42rpx;color:red;font-weight:bold;text-align:center;'} className="swiper__item--itext">{index + 1}：这里是文案</View>
        <View style={'font-size:42rpx;color:red;font-weight:bold;text-align:center;'} className="swiper__item--itext">点击了第{count}张</View>
          <Image style={'width:750rpx;height:370rpx;'} src={item.imgSrc} className="swiper__item--images"></Image>
        </View>
      </SwiperItem>)}
  </Swiper>

    </View>;
  }

  componentDidMount() {
    super.componentDidMount && super.componentDidMount();
  }

  componentDidShow() {
    super.componentDidShow && super.componentDidShow();
  }

  componentDidHide() {
    super.componentDidHide && super.componentDidHide();
  }

}