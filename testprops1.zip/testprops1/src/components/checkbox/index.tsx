import Taro from '@tarojs/taro'
import { View } from '@tarojs/components'
import classNames from 'classnames'
import { CheckboxOptionProps } from '../../../@types/checkbox'
// import styles from './index.module.scss'
var styles = require('./index.module.scss')

function getStyleObj (props: CheckboxOptionProps) {
  let _styleObj = {}
  return _styleObj
}

function getClassObject (props: CheckboxOptionProps) {
  const classObject = {
    [styles['checkbox__option--disabled']]: props.isDisabled,
    [styles['checkbox__option--custom-label']]: typeof props.children !== 'string'
  };
  return classObject;
}

export default function CheckboxOption (props: CheckboxOptionProps) {
  const rootClassName = styles['checkbox__option'];//组件
  const classObject = getClassObject(props);//组件修饰
  const styleObject = getStyleObj(props);

  const {
    value = []
  } = props;

  const onClickOption = (props: CheckboxOptionProps) => {
    if (props.isDisabled)
      return;
    let newValues = value;
    if (value.includes(props.optionValue)) {
      newValues = value.filter((v) => {
        return v !== props.optionValue;
      });
    } else {
      newValues.push(props.optionValue);
    }
    props.onClick(newValues);
  };

  let iconType = 'choose';
  let color;
  if (props.isDisabled) {
    iconType = styles['choose-disable'];
  } else if (value.includes(props.optionValue)) {
    iconType = styles['choose-selected'];
  }
  return (
    <View
      className={
        classNames([rootClassName, classObject, iconType])
      }
      style={styleObject}
      onClick={() => onClickOption(props)}
    >
      {props.children}
    </View>
  );
}

