import Taro from '@tarojs/taro'
import { View } from '@tarojs/components'
import classNames from 'classnames'
import { OsRadioProps } from '../../../@types/index'
// import styles from './index.module.scss'
var styles = require('./index.module.scss')

function getStyleObj (props: OsRadioProps) {
  let _styleObj = {}
  return _styleObj
}

function getClassObject (props: OsRadioProps) {
  const classObject = {
    [`radio--dir-${props.type}`]: true
  }
  return classObject
}

export default function Index (props: OsRadioProps) {
  const rootClassName = styles['radio'];//组件
  const classObject = getClassObject(props);//组件修饰
  const styleObject = getStyleObj(props);

  return (
    <View
      className={classNames(rootClassName, styles['radio-root-class'], classObject, props.className)}
      style={styleObject}
    >
      {/* <View className={classNames(styles['radio__options'], this.props.type === 'row' ? styles['radio__options--row']:'')}>
        {props.children}
      </View> */}
       {props.children}
    </View>
  );
}

Index.defaultProps = {
  type: 'column'
}

// Index.options = {
//   addGlobalClass: true
// }
